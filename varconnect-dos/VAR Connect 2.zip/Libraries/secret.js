define([], function() {
    return {
        consumer: {
            public: '0069214e773ab05e6c51dff4660a3ed54ea967652f22c232fe82101be7435012',
            secret: '6970b0e4486fe544343ecb23c0e8099bdf2d46bed677a628367b79f07979741e'
        },
        realm: 'TSTDRV2486528'
    }
});